# 结果滚动职责精简 · 2026-10-24

唯一开发基线为上一轮完整交付 `b2dee87`。本轮维护候选只修改 `src/features/results/viewport-geometry-methods.js` 的两个方法；未晋升冻结版本。

## 根因与边界

沿 `SearchView.onOpen → SearchCore → attachViewport → handleScrollLoad / _markNativeScroll → _settleNativeScroll` 检查了事件、定时器、清理、几何补偿、结果索引与共享状态的阻塞/恢复链。还核查了结果点击/批量/键盘路径、会话保存、移动侧滑及现有 CSS/Style Settings 职责。没有修改样式、DOM、视觉 Token、设置、Popup、焦点、索引结构或共享状态模型。

原实现对结果区任意鼠标按下，以及空格等控件按键，在没有滚动时也启动 180ms 滚动停稳事务。这个状态会临时阻塞索引与跨窗口查询消费。停稳再调用 `_notifyStateChange`，重新捕获、比较、发布没有变化的查询并同步左侧导航，只为保存当前窗口位置。

- 删除 viewport Owner 的 `pointerdown`、`keydown` 捕获监听及其回调。真正的鼠标滚动条拖动和键盘滚动由现有 `scroll → handleScrollLoad` 处理，不再把普通点击当成滚动。批量选择自身的 pointerdown 焦点规则继续保留。
- 停稳调用 `onStateChange` 保存宿主视口，取代查询级通知。此前的 `_scheduleResultIndexUpdate` 保留，既恢复待处理索引，也通过现有 coordinator 恢复待处理共享查询；没有新增缓存、事件状态或第二个调度器。
- 触摸与滚轮的提前滚动意图、移动侧滑、滚动中几何补偿、样式变更延后处理、程序定位排除、卸载取消均沿用原实现。触摸结束需要释放既有阻塞，不能直接当成多余监听删除。

## 对照证据

`scripts/result_scroll_owner_audit.py` 通过真实 `SearchView.onOpen` 加载受控 Obsidian fixture，并使用 Chromium 原生鼠标与键盘。旧版隔离目录从 `git archive b2dee87` 创建；前后使用相同专项脚本。

| 操作 | 旧版 | 本轮 |
|---|---:|---:|
| 普通鼠标按住：滚动事务 / 导航同步 / 查询发布 / 位置保存 | 各 1 次 | 各 0 次 |
| 按钮空格激活：滚动事务 / 导航同步 / 查询发布 | 各 1 次 | 各 0 次 |
| 无后台变化的真实滚动停稳：导航同步 / 查询发布 | 各 1 次 | 各 0 次 |
| 真实滚动停稳：宿主位置保存 | 保留 | 保留 |

测量的是调用次数，不是整机帧率或加速百分比。滚动停稳仍使用原 180ms；移除的是非滚动操作误入这条等待链。后台确有变化时可以同步导航，不能为了“零刷新”丢掉更新。

专项验证覆盖普通按压、选中、按钮激活、实际键盘/滚轮滚动、位置保存、程序定位、待处理索引与共享查询以及关闭清理。原生 Obsidian、第三方主题/用户 CSS、iOS、Android、WebKit 未在本环境实测；不宣称全产品已完美或全部卡顿已解决。

## 验证与交付

- 工程检查与标准构建通过：153 个模块、666 条依赖，无未解析符号与环。
- 新增滚动专项 19/19；相同脚本在唯一旧基线 11/19，8 项未达到新的最短调用链要求。初版 16 项证据也保留。
- 桌面结果/移动侧滑专项 36/36；结果卡复用 25/25；搜索条件 144/144。
- 焦点 56/56、焦点修复 96/96、飞书对照 8/8、光标 36/36、Portal Chromium 48/48、移动侧栏 96/96、索引重试 7/7。
- 静置 1.5 秒没有受监测调用或 DOM 写入；关闭重开 6 次后节点及监听数量稳定。生命周期测试去除 fixture 历史事件日志保留回调的干扰，只统计活动监听。
- 全量 Node 268/272，4 项为历史冻结方法 ABI 比较失败；浏览器旧快照四种配置均停在 `01-initial` 差异，后续 B 场景没有通过该门禁执行。没有隐藏失败或修改旧基线。
- 全源 JS/CSS 静态审计通过；本轮未更改 CSS，未增加 Style Settings 或 CSS Snippet 控制源。

验证结果及包校验记录在 `reports/result-scroll-owner-20261024/`。原有冻结 ABI/视觉快照与当前产品不同，旧门禁失败单独记录，不修改历史基线来使测试通过。

运行包只含 `main.js`、`styles.css`，来自本轮构建；CSS 与上一版一致。退出 Obsidian 后覆盖插件目录这两个文件，保留原 `manifest.json` 和 `data.json`，再启动。源码由本分支提交保存。

覆盖包：`GLS-Result-Scroll-Optimized-20261024.zip`；SHA256：`2d5ad9491b33ce8c8b76a51194a241bd08024e0893e41d77f178466f78312756`。CRC 及两项文件与当前 dist 字节校验均通过。

[下载已校验覆盖包](https://github.com/13858812638-glitch/MoNian/raw/ed35d892e1b4afa3f7337997b6e8eef73bfaa152/downloads/GLS-Result-Scroll-Optimized-20261024.zip)。实际 HTTP 下载返回 200，远端文件与本地 ZIP / 当前 dist 内容完全一致。
