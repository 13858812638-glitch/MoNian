# GLS 原生属性隐藏迁移 · 源码及运行文件

日期：2026-10-25（北京时间）
唯一源码提交：ab898f7dcc9aa5fa087fe326427a7534b183fbe1

## 安装

1. 将 Snippets/GLS-Hide-Internal-Properties.css 放到仓库配置目录的 snippets 文件夹（通常 .obsidian/snippets/）。可以通过 Obsidian 设置 → 外观 → CSS 代码片段的文件夹按钮定位。
2. 在同一设置页刷新片段列表，启用 GLS-Hide-Internal-Properties。桌面和手机分别确认片段存在且已启用。
3. 退出 Obsidian，将 Runtime/main.js、Runtime/styles.css 覆盖现有 GLS 插件目录，保留原 manifest.json、data.json，再启动。

必须一并更新插件 styles.css，才能删除插件内原规则和 Style Settings 开关。之后六个 GLS 内部字段仅由 CSS 片段控制，不依赖插件启动。停用片段即可恢复显示；普通属性及 YAML 内容不变。

## 源码

Source/ 为完整当前工程；仅 Source/src 是后续插件开发起点，Source/snippets 是独立片段源。Source/baseline 只是历史只读测试对照，不是待安装版本。未包含 Git、node_modules、用户数据、历史 downloads ZIP 或临时文件。

Node.js 22+，在 Source/ 执行 npm ci 然后 npm run build。输出 dist 中的两项插件运行文件；片段独立由 Obsidian 加载，不编入插件 CSS。

原真实 manifest 没有提供，本包是已有插件的覆盖更新，不伪造新安装身份。

本次只修改 CSS，不修改运行 JS。测试结果、历史失败与原生平台未验证范围见 Source/docs/INTERNAL_PROPERTIES_SNIPPET_20261025.md。历史测试部分包含原提取环境绝对路径，完整旧基线对照可能需要路径映射；普通源码构建无需此映射。

CHECKSUMS.json 记录包内各文件大小及 SHA256。
