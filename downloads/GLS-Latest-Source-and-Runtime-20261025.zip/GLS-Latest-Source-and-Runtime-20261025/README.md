# GLS Navigator 最新源码与运行文件

打包日期：2026-10-25（北京时间）
唯一源码版本：76f83bb974be6eeaa5578ab04cfbcc879fbe8e87
分支：fix/desktop-sidebar

## 内容

- Source/：完整当前工程，含 src、dist、构建配置、锁定依赖清单、测试、审计文档和历史只读 baseline。
- Runtime/：main.js、styles.css，可覆盖已有插件安装。
- CHECKSUMS.json：包内文件逐项 SHA256 与大小。

仅 Source/src 是后续开发起点。baseline 是测试对照资料，不是另一套待安装版本；downloads 历史交付 ZIP、.git、node_modules 和临时文件未包含。

## 使用运行文件

退出 Obsidian，将 Runtime/main.js 和 Runtime/styles.css 覆盖到现有 GLS 插件目录；保留原 manifest.json、data.json 后重启。原项目没有提供真实 manifest，本包不会伪造插件身份，因此不是全新安装包。

## 构建源码

使用 Node.js 22 或更新版本，在 Source 目录执行：

    npm ci
    npm run build

输出是 Source/dist/main.js 与 Source/dist/styles.css。依赖不打入源码包，npm ci 按 package-lock.json 安装。浏览器专项另外需要 Python、Playwright 与 Chromium。

## 验证状态

本次仅打包，不修改产品代码。重新构建的两个运行文件与上一轮已交付版本逐字节一致，并对完整 ZIP 做 CRC 和逐文件哈希验证。
上一轮测试结果、原生环境未验证范围及历史门禁失败见 Source/docs/RESULT_SCROLL_OWNER_20261024.md。
历史对照资料中含原提取环境的绝对路径；完整旧基线对照测试可能需要路径映射，这不影响上述源码构建命令。不要修改 baseline 来掩盖历史比较失败。
